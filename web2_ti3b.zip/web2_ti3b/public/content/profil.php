<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  </head>
  <body>
    <div class="container">
      <div class="header">
        <h1>La Ode Rama</h1>
        <p>This Is My Gallery</p>
      </div>
      <div class="gallery">
        <img src="galery/1.jpg" />
        <img src="galery/11.jpg" />
        <img src="galery/u.jpg" />
        <img src="galery/3.jpg" />
        <img src="galery/4.jpg" />
        <img src="galery/5.jpg" />
      </div>
    </div>
  </body>
</html>

<style type="text/css">
    .header img {
    width: 150px;
    height: 150px;
    border-radius: 100%;
    object-fit: cover;
  }
  .gallery {
    margin: 50px 0;
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    grid-gap: 25px;
  }
  .gallery img {
    width: 100%;
    height: 280px;
    object-fit: cover;
    box-shadow: 1px 2px 3px burlywood;
    border-radius: 10px;
    box-sizing: border-box;
  }
  .container {
    box-sizing: border-box;
    text-align: center;
  }
</style>